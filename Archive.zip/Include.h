#pragma once

#include <OpenGL/gl.h>
#include <GLFW/glfw3.h>

#include "linmath.h"
#include "Mesh.h"
#include "Renderer.h"
