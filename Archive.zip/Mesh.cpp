#include "Mesh.h"

Mesh::Mesh(int N_, float initialDistance_)
    : N(N_), initialDistance(initialDistance_) {};

void Mesh::generateMesh() {
    // spencer's code here

}

void Mesh::update() {
    // physics here, must complete before rendering
}